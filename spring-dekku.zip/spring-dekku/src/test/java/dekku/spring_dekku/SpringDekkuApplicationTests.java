package dekku.spring_dekku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDekkuApplicationTests {

	@Test
	void contextLoads() {
	}

}
