package dekku.spring_dekku.domain.product.model.entity.code;

public enum ExistStatus {
    NOT_EXIST, EXIST;
}
