package dekku.spring_dekku.domain.product.service;

import dekku.spring_dekku.domain.product.model.dto.request.CreateProductRequestDto;
import dekku.spring_dekku.domain.product.model.dto.response.CreateProductResponseDto;
import dekku.spring_dekku.domain.product.model.entity.Product;
import dekku.spring_dekku.domain.product.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    @Transactional
    public CreateProductResponseDto saveProduct(CreateProductRequestDto requestDto) {
        Product product = requestDto.toEntity();
        Product savedProduct = productRepository.save(product);
        return CreateProductResponseDto.fromEntity(savedProduct);
    }

    public List<CreateProductResponseDto> findAllProductDtos() {
        List<Product> products = productRepository.findAll();
        return products.stream()
                .map(CreateProductResponseDto::fromEntity)
                .collect(Collectors.toList());
    }
}
