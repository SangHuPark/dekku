package dekku.spring_dekku.domain.member.model.entity.code;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MemberRole {
    COMMON, ADMIN
}
