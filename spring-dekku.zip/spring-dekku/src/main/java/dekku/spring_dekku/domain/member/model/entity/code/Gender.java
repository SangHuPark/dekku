package dekku.spring_dekku.domain.member.model.entity.code;

public enum Gender {
    NON_SELECT, WOMAN, MAN
}
