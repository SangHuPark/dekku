package dekku.spring_dekku.domain.product.model.dto.request;

import dekku.spring_dekku.domain.product.model.entity.FilePath;
import dekku.spring_dekku.domain.product.model.entity.Product;
import dekku.spring_dekku.domain.product.model.entity.code.Category;
import dekku.spring_dekku.domain.product.model.entity.code.ExistStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateProductRequestDto {

    private String name; // 제품명
    private int price; // 제품 가격
    private String imageUrl; // 이미지 url
    private String salesLink; // 파트너스 링크
    private ExistStatus existStatus; // 모델 존재 여부
    private Category category; // 제품 카테고리
    private FilePath filePath; // 내부 3D 파일 경로

    public Product toEntity() {
        return Product.builder()
                .name(name)
                .price(price)
                .imageUrl(imageUrl)
                .salesLink(salesLink)
                .existStatus(existStatus)
                .category(category)
                .filePath(filePath)
                .build();
    }
}
