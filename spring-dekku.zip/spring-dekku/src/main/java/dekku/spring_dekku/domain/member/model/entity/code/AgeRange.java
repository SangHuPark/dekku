package dekku.spring_dekku.domain.member.model.entity.code;

public enum AgeRange {
    TEN, TWENTY, THIRTY, FORTY, FIFTY, OLDER
}
