package dekku.spring_dekku.domain.product.model.entity.code;

public enum Category {
    MONITOR, LAPTOP, MOUSE, KEYBOARD, DESK, ETC
}
