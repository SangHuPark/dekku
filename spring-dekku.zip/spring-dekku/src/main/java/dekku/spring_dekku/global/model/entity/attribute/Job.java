package dekku.spring_dekku.global.model.entity.attribute;

public enum Job {
    NON_SELECT,
    OFFICEWORKER,
    DEVELOPER,
    ARCHITECT,
    DESIGNER,
    EDITOR,
    WRITER,
    FREELANCER,
    HOMEMAKER,
    STUDENT,
    ETC
}
