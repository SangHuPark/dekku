package dekku.spring_dekku.global.model.entity.attribute;

public enum Style {
    NON_SELECT,
    MODERN,
    MINIMAL,
    RETRO,
    LOVELY,
    GAMER,
    LIBRARY,
    NATURE,
    ETC
}
