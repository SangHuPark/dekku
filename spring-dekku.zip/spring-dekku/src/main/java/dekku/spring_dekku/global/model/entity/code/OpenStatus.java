package dekku.spring_dekku.global.model.entity.code;

public enum OpenStatus {
    OPENED,
    CLOSED
}
