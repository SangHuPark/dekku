package dekku.spring_dekku.global.model.entity.attribute;

public enum Color {
    NON_SELECT,
    BLACK_AND_WHITE,
    BLACK,
    WHITE,
    GRAY,
    MINT,
    BLUE,
    PINK,
    GREEN,
    RED,
    YELLOW,
    BROWN,
    ETC
}
